# Finished Issue Overview — approved visual implementation bundle

This bundle contains the approved visual implementation for the Finished Issue **Overview** section.

The bundle is intended to be extracted directly under `Frontend/` and used by Codex as the source of truth for the visual integration.

## Scope

Integrate only the Overview detailed section.

Do not redesign:

- Dashboard
- Results analysis
- Evaluations
- Consensus
- Models
- Finished Issue header/navigation
- Backend/API contract

## Target repository paths

Copy or adapt the supplied files into:

`Frontend/src/features/finishedIssueDialog/sections/overview/`

The bundle provides:

```text
sections/overview/
├── OverviewSection.jsx
├── overview.styles.js
├── logic/
│   └── buildFinishedIssueOverviewData.js
└── components/
    ├── OverviewView.jsx
    ├── OverviewPanel.jsx
    ├── OverviewSummaryStrip.jsx
    ├── IssueInformationPanel.jsx
    ├── AlternativesPanel.jsx
    ├── CriteriaStructurePanel.jsx
    ├── CriteriaTreeNode.jsx
    ├── ParticipationPanel.jsx
    ├── ConfigurationDomainsPanel.jsx
    ├── OverviewExecutionFooter.jsx
    └── charts/
        └── ParticipationDonutChart.jsx
```

`REFERENCE_OVERVIEW.png` is the approved visual target.

## Visual objective

Match the approved Overview composition:

1. Existing Finished Issue shell/header/navigation.
2. Existing `Back to dashboard` action.
3. One compact factual summary strip.
4. Large Issue information panel.
5. Alternatives panel.
6. Recursive Criteria structure panel.
7. Experts & participation panel with a doughnut chart.
8. Configuration & domains panel.
9. Bottom factual result-evidence strip.

Use the Dashboard visual language already integrated:

- dark navy
- cyan/teal
- blue
- restrained green success accents
- red only for factual cost/error/destructive states
- rounded panels
- thin borders
- no yellow/orange decorative accents
- no excessive blur or diffuse glow

## Critical criteria-tree requirement

The criteria UI must support arbitrary depth:

```text
Root
├── Child
│   ├── Grandchild
│   │   └── Great-grandchild
│   └── Child
└── Child
```

Never assume only one child level.

The supplied builder recursively reconstructs `children` from:

- `payload.criteria.nodes`
- `payload.criteria.rootIds`
- each node's `childIds`

The supplied `CriteriaTreeNode` recursively renders every depth.

Requirements:

- Stable criterion IDs as React keys.
- Cycle protection in the builder.
- Parent nodes expandable/collapsible.
- Deep trees remain horizontally readable.
- Large trees scroll inside the panel.
- Every leaf may show:
  - Benefit/Cost
  - final weight
  - expression domain
- Parent nodes may show child count.
- Do not flatten the hierarchy.
- Do not use array index as the canonical node key.
- Do not limit rendering to children or grandchildren.

## Data rules

Use only canonical Finished Issue facts.

Do not invent:

- execution IDs
- model runs
- criterion weights
- domain names
- participant completion
- consensus status
- timestamps

The bottom evidence strip uses the latest stored alternative-evaluation phase result when available:

- phase result ID
- created/updated date
- phase
- creator/owner
- Base execution mode

When evidence is unavailable, display `—`.

## Builder compatibility

The supplied `buildFinishedIssueOverviewData.js` preserves:

- `buildOverviewData(payload)`
- `buildOverviewPreview(data)`
- the Dashboard preview fields already consumed elsewhere

The Dashboard must continue working after integration.

The builder enriches the detailed Overview contract with:

- summary strip
- full recursive criteria tree
- final weights
- expression-domain associations
- participant status/completion
- participation chart data
- configuration details
- latest stored result evidence

## Existing shell frame

Do not add another Overview-only max-width.

The Finished Issue shell already centers detailed sections.

## Chart dependency

`ParticipationDonutChart` uses:

- `chart.js`
- `react-chartjs-2`

Both are already installed.

Do not add another chart library.

## Old Overview files

The old accordion-based components may be removed when unused:

- GeneralInformation.jsx
- DescriptionSection.jsx
- AlternativesSection.jsx
- CriteriaSection.jsx
- CriterionItem.jsx
- ExpertsSection.jsx
- ConsensusConfiguration.jsx

Do not delete shared Finished Issue primitives used by other sections.

## Architecture

`OverviewSection.jsx` remains the container:

- reads Finished Issue context
- calls `buildOverviewData`
- passes explicit `data` to `OverviewView`

Overview presentational components:

- do not read context
- do not call services
- do not access raw payload
- do not normalize canonical entities

Overview logic:

- imports no React/MUI
- returns serializable data
- owns hierarchy/domain/participant associations

## Responsive behavior

Desktop:

- summary strip: six columns
- top row: Issue information + Alternatives
- bottom row: Criteria + Participation + Configuration

Tablet:

- summary strip wraps
- two-column content where practical
- Configuration may span width

Mobile:

- one column
- recursive tree remains scrollable
- participant layout stacks
- footer metadata wraps
- no horizontal page overflow

## Integration checklist

1. Inspect current Overview files before replacement.
2. Copy supplied files to their target paths.
3. Adjust relative imports only when repository paths differ.
4. Keep `OverviewSection` exported through the existing public index.
5. Verify `Back to dashboard` remains owned by the existing Finished Issue layout.
6. Preserve Dashboard `buildOverviewPreview` behavior.
7. Remove obsolete Overview-only files after imports are migrated.
8. Do not modify the Finished Issue header or Dashboard.
9. Add semantic tests.
10. Run test/lint/build/diff check.

## Required tests

Add or update focused tests for:

1. OverviewView renders without FinishedIssueDialogProvider.
2. Summary strip shows canonical owner, model, date, accepted participants and consensus.
3. Issue information uses canonical name/description/lifecycle.
4. Alternatives render stable IDs, names and optional descriptions.
5. Recursive criteria render at least four levels.
6. Parent criteria can be expanded/collapsed.
7. Leaf criteria show Benefit/Cost.
8. Final criterion weight is associated by criterion ID.
9. Expression domain is associated by `expressionDomainId`.
10. Orphan or missing child IDs do not crash.
11. Cyclic malformed criteria evidence does not recurse forever.
12. Participants preserve accepted/pending/declined distinctions.
13. Completion percentage uses completed accepted participants / accepted participants.
14. Zero accepted participants does not create NaN/Infinity.
15. Doughnut chart renders with canonical participant data.
16. Configuration shows the alternative-evaluation structure.
17. Configuration shows criteria-weighting source/model where available.
18. Expression domains list the criteria assigned to each snapshot.
19. Latest phase-result evidence uses a real phase result ID.
20. Missing phase-result evidence displays `—`.
21. Copy result ID action is accessible.
22. `buildOverviewPreview` still supplies the current Dashboard fields.
23. No old accordion disclosure state is required.
24. No Backend files are modified.

Avoid screenshot snapshots.

## Verification

Run:

```bash
cd Frontend
bun run test
bun run lint
bun run build
git diff --check
```

## Completion report

Report:

1. Bundle path used.
2. Overview files integrated.
3. Builder enrichments.
4. Arbitrary-depth criteria behavior.
5. Participant chart behavior.
6. Configuration/domain associations.
7. Evidence footer behavior.
8. Old files removed.
9. Tests added/updated.
10. Verification results.
11. Confirmation that no other section or Backend was redesigned.
