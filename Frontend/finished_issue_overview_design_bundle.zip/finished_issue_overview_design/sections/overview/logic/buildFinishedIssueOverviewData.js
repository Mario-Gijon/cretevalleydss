const asArray = (value) => (Array.isArray(value) ? value : []);

const isNonEmptyString = (value) =>
  typeof value === "string" && value.trim().length > 0;

const participantLabel = (participant) => {
  const name = participant?.expert?.name || "Unknown participant";
  const email = participant?.expert?.email;
  return email ? `${name} (${email})` : name;
};

const formatTechnicalLabel = (value) => {
  if (!isNonEmptyString(value)) return "—";

  return value
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
};

const dateTimestamp = (value) => {
  if (!value) return 0;
  const timestamp = new Date(value).getTime();
  return Number.isFinite(timestamp) ? timestamp : 0;
};

const sortPhaseResults = (left, right) => {
  const phaseDifference = Number(right?.phase ?? -1) - Number(left?.phase ?? -1);
  if (phaseDifference !== 0) return phaseDifference;

  return (
    dateTimestamp(right?.updatedAt || right?.createdAt) -
    dateTimestamp(left?.updatedAt || left?.createdAt)
  );
};

const buildCriteriaTree = ({
  nodes,
  rootIds,
  finalWeights,
  expressionDomains,
}) => {
  const canonicalNodes = asArray(nodes);
  const domainById = new Map(
    asArray(expressionDomains).map((domain) => [domain?.id, domain])
  );
  const byId = new Map(canonicalNodes.map((node) => [node?.id, node]));

  const visit = (id, path = new Set()) => {
    if (!id || path.has(id)) return null;

    const node = byId.get(id);
    if (!node) return null;

    const nextPath = new Set(path);
    nextPath.add(id);

    return {
      id: node.id,
      name: node.name || "Unnamed criterion",
      description: node.description || "",
      type: node.type || null,
      isLeaf: node.isLeaf === true,
      parentId: node.parentId || null,
      position: node.position ?? null,
      weight:
        finalWeights?.byCriterionId &&
        Object.prototype.hasOwnProperty.call(
          finalWeights.byCriterionId,
          node.id
        )
          ? finalWeights.byCriterionId[node.id]
          : null,
      expressionDomainId: node.expressionDomainId || null,
      expressionDomain:
        domainById.get(node.expressionDomainId) || null,
      children: asArray(node.childIds)
        .map((childId) => visit(childId, nextPath))
        .filter(Boolean),
    };
  };

  const rootSet = new Set(asArray(rootIds));
  const orphanRootIds = canonicalNodes
    .filter(
      (node) =>
        node?.id &&
        !rootSet.has(node.id) &&
        (!node.parentId || !byId.has(node.parentId))
    )
    .map((node) => node.id);

  return [...asArray(rootIds), ...orphanRootIds]
    .map((id) => visit(id))
    .filter(Boolean);
};

const buildDomainSummaries = (domains, criteriaNodes) => {
  const criterionNamesByDomainId = new Map();

  asArray(criteriaNodes).forEach((criterion) => {
    if (!criterion?.expressionDomainId) return;

    const current =
      criterionNamesByDomainId.get(criterion.expressionDomainId) || [];
    current.push(criterion.name || "Unnamed criterion");
    criterionNamesByDomainId.set(criterion.expressionDomainId, current);
  });

  return asArray(domains).map((domain) => ({
    id: domain?.id || null,
    name: domain?.name || "Unnamed domain",
    typeKey: domain?.typeKey || null,
    typeLabel: formatTechnicalLabel(domain?.typeKey),
    definition: domain?.definition ?? null,
    criterionNames: criterionNamesByDomainId.get(domain?.id) || [],
  }));
};

const buildParticipantSummary = (participants) => {
  const records = asArray(participants).map((participant) => {
    const status = participant?.invitationStatus || "unknown";
    const accepted = status === "accepted";
    const completed = participant?.evaluationCompleted === true;

    return {
      id: participant?.id || null,
      expertId: participant?.expert?.id || null,
      name: participant?.expert?.name || "Unknown participant",
      email: participant?.expert?.email || null,
      university: participant?.expert?.university || null,
      invitationStatus: status,
      evaluationCompleted: completed,
      weightsCompleted: participant?.weightsCompleted === true,
      currentWeight: participant?.currentWeight ?? null,
      entryStage: participant?.entryStage || null,
      entryPhase: participant?.entryPhase ?? null,
      joinedAt: participant?.joinedAt || null,
      accepted,
      completed,
    };
  });

  const accepted = records.filter((participant) => participant.accepted);
  const completedAccepted = accepted.filter(
    (participant) => participant.completed
  );
  const acceptedIncomplete = accepted.filter(
    (participant) => !participant.completed
  );
  const pending = records.filter(
    (participant) => participant.invitationStatus === "pending"
  );
  const declined = records.filter(
    (participant) => participant.invitationStatus === "declined"
  );

  return {
    records,
    total: records.length,
    accepted: accepted.length,
    completed: completedAccepted.length,
    acceptedIncomplete: acceptedIncomplete.length,
    pending: pending.length,
    declined: declined.length,
    completionPercentage:
      accepted.length > 0
        ? Math.round((completedAccepted.length / accepted.length) * 100)
        : null,
    chart: {
      completed: completedAccepted.length,
      acceptedIncomplete: acceptedIncomplete.length,
      pending: pending.length,
      declined: declined.length,
      total: records.length,
    },
  };
};

export const buildOverviewData = (payload) => {
  const lifecycle = payload?.lifecycle || {};
  const consensus = payload?.consensus || {};
  const participants = asArray(payload?.participants);
  const acceptedParticipants = participants.filter(
    (participant) => participant?.invitationStatus === "accepted"
  );
  const notAcceptedParticipants = participants.filter(
    (participant) => participant?.invitationStatus !== "accepted"
  );
  const criteria = payload?.criteria || {};
  const criteriaNodes = asArray(criteria.nodes);
  const finalWeights =
    criteria?.finalWeights || { source: null, byCriterionId: {} };
  const expressionDomains = asArray(payload?.expressionDomains);
  const participation = buildParticipantSummary(participants);
  const criteriaTree = buildCriteriaTree({
    nodes: criteriaNodes,
    rootIds: criteria.rootIds,
    finalWeights,
    expressionDomains,
  });
  const domainSummaries = buildDomainSummaries(
    expressionDomains,
    criteriaNodes
  );
  const alternativeResults = asArray(payload?.phaseResults)
    .filter((result) => result?.stage === "alternativeEvaluation")
    .sort(sortPhaseResults);
  const latestAlternativeResult = alternativeResults[0] || null;
  const baseModel = payload?.models?.base || null;
  const weightingModel = payload?.models?.criteriaWeighting || null;
  const configuration = payload?.configuration || {};

  const issue = {
    id: payload?.issue?.id || null,
    name: payload?.issue?.name || "",
    description: payload?.issue?.description || "",
    owner: payload?.issue?.owner || null,
    creator: payload?.issue?.creator || null,
    lifecycle,
  };

  const detailedConfiguration = {
    baseModel: {
      id: baseModel?.id || null,
      name: baseModel?.name || "—",
    },
    consensus: {
      enabled: consensus.enabled === true,
      supported:
        consensus.modelSupportsConsensus ??
        configuration?.consensus?.supported ??
        null,
      simulated:
        consensus.simulated ??
        configuration?.consensus?.simulated ??
        null,
      threshold:
        consensus.threshold ??
        configuration?.consensus?.threshold ??
        null,
      maxPhases:
        consensus.maxPhases ??
        configuration?.consensus?.maxPhases ??
        null,
    },
    alternativeEvaluation: {
      structureKey:
        configuration?.alternativeEvaluation?.structureKey || null,
      structureLabel: formatTechnicalLabel(
        configuration?.alternativeEvaluation?.structureKey
      ),
    },
    criteriaWeighting: {
      required:
        configuration?.criteriaWeighting?.required === true,
      source: configuration?.criteriaWeighting?.source || null,
      sourceLabel: formatTechnicalLabel(
        configuration?.criteriaWeighting?.source
      ),
      structureKey:
        configuration?.criteriaWeighting?.structureKey || null,
      structureLabel: formatTechnicalLabel(
        configuration?.criteriaWeighting?.structureKey
      ),
      modelId:
        configuration?.criteriaWeighting?.modelId ||
        weightingModel?.id ||
        null,
      modelName: weightingModel?.name || null,
    },
    domainCount: expressionDomains.length,
    assignedDomainCriteriaCount: criteriaNodes.filter(
      (criterion) => Boolean(criterion?.expressionDomainId)
    ).length,
    domains: domainSummaries,
  };

  return {
    issue,
    general: {
      name: issue.name,
      owner:
        issue.owner?.name || issue.owner?.email || "—",
      model: baseModel?.name || "—",
      creationDate: lifecycle.creationDate ?? lifecycle.createdAt ?? null,
      closureDate: lifecycle.closureDate ?? lifecycle.finishedAt ?? null,
    },
    summary: {
      owner: issue.owner?.name || issue.owner?.email || "—",
      model: baseModel?.name || "—",
      createdAt:
        lifecycle.creationDate ?? lifecycle.createdAt ?? null,
      execution: "Base",
      acceptedParticipants: participation.accepted,
      consensusEnabled: consensus.enabled === true,
    },
    description: issue.description,
    configuration: detailedConfiguration,
    alternatives: asArray(payload?.alternatives).map((alternative) => ({
      id: alternative?.id || null,
      name: alternative?.name || "Unnamed alternative",
      description: alternative?.description || "",
      position: alternative?.position ?? null,
    })),
    criteria: criteriaTree,
    criteriaHierarchy: criteria,
    finalCriteriaWeights: finalWeights,
    expressionDomains,
    domainSummaries,
    participants: participation.records,
    participation,
    experts: {
      total: participants.length,
      participated: acceptedParticipants.map(participantLabel),
      notAccepted: notAcceptedParticipants.map(participantLabel),
    },
    counts: {
      alternatives: asArray(payload?.alternatives).length,
      criteria: criteriaNodes.length,
      leafCriteria: criteriaNodes.filter((node) => node?.isLeaf).length,
      participants: participants.length,
      expressionDomains: expressionDomains.length,
    },
    consensus: consensus.enabled
      ? {
          threshold: consensus.threshold ?? null,
          maxPhases: consensus.maxPhases ?? null,
          reachedPhaseLabel: consensus.reachedPhase ?? "—",
          finalizationReason: consensus.finalizationReason ?? null,
          finalMeasure:
            alternativeResults[0]?.consensusMeasure ?? null,
        }
      : null,
    evidence: {
      resultId: latestAlternativeResult?.id || null,
      storedAt:
        latestAlternativeResult?.createdAt ||
        latestAlternativeResult?.updatedAt ||
        null,
      phase: latestAlternativeResult?.phase ?? null,
      executedBy:
        issue.creator?.name ||
        issue.owner?.name ||
        issue.creator?.email ||
        issue.owner?.email ||
        "—",
      executionMode: "Base",
      contractVersion:
        payload?.executionMetadata?.contractVersion ?? null,
      generatedAt:
        payload?.executionMetadata?.generatedAt ?? null,
    },
  };
};

export const buildOverviewPreview = (data) => ({
  id: data.issue.id,
  name: data.issue.name,
  description: data.description,
  owner: data.general.owner,
  ownerEmail: data.issue.owner?.email || null,
  baseModelName: data.general.model,
  creationDate: data.general.creationDate,
  closureDate: data.general.closureDate,
  lifecycleStage:
    data.issue.lifecycle?.active === false ? "Finished" : "Active",
  consensusEnabled: Boolean(data.consensus),
  alternativesCount: data.counts.alternatives,
  criteriaCount: data.counts.criteria,
  participantsCount: data.counts.participants,
  acceptedParticipantsCount: data.participation.accepted,
  completedAlternativeEvaluationsCount: data.participation.completed,
});

export default buildOverviewData;
