export const overviewRootSx = {
  width: "100%",
  minWidth: 0,
};

export const overviewSummaryStripSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "repeat(2, minmax(0, 1fr))",
    sm: "repeat(3, minmax(0, 1fr))",
    xl: "repeat(6, minmax(0, 1fr))",
  },
  mb: { xs: 1.5, md: 2 },
  border: "1px solid rgba(91, 207, 219, 0.18)",
  borderRadius: 3,
  overflow: "hidden",
  bgcolor: "rgba(8, 19, 30, 0.90)",
  background:
    "linear-gradient(112deg, rgba(22, 91, 123, 0.19), rgba(8, 20, 32, 0.94) 48%, rgba(22, 98, 80, 0.13))",
  boxShadow: "0 14px 34px rgba(0,0,0,0.16)",
};

export const overviewSummaryItemSx = (index) => ({
  minWidth: 0,
  minHeight: { xs: 76, xl: 82 },
  px: { xs: 1.15, md: 1.4 },
  py: 1.1,
  display: "flex",
  alignItems: "center",
  gap: 1,
  borderRight: {
    xs: index % 2 === 0 ? "1px solid rgba(255,255,255,0.075)" : 0,
    sm: index % 3 !== 2 ? "1px solid rgba(255,255,255,0.075)" : 0,
    xl: index < 5 ? "1px solid rgba(255,255,255,0.075)" : 0,
  },
  borderBottom: {
    xs: index < 4 ? "1px solid rgba(255,255,255,0.075)" : 0,
    sm: index < 3 ? "1px solid rgba(255,255,255,0.075)" : 0,
    xl: 0,
  },
});

export const overviewSummaryIconSx = (tone = "cyan") => ({
  width: 38,
  height: 38,
  display: "grid",
  placeItems: "center",
  flexShrink: 0,
  borderRadius: "50%",
  color: tone === "green" ? "success.light" : "secondary.light",
  bgcolor:
    tone === "green"
      ? "rgba(64, 192, 137, 0.12)"
      : "rgba(47, 157, 199, 0.12)",
  border: "1px solid rgba(255,255,255,0.065)",
});

export const overviewTopGridSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    lg: "1.08fr 0.92fr",
  },
  gap: { xs: 1.5, md: 1.75 },
  mb: { xs: 1.5, md: 1.75 },
  alignItems: "stretch",
};

export const overviewBottomGridSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    md: "repeat(2, minmax(0, 1fr))",
    xl: "1.05fr 1fr 1.1fr",
  },
  gridTemplateAreas: {
    xs: `"criteria" "participation" "configuration"`,
    md: `"criteria participation" "configuration configuration"`,
    xl: `"criteria participation configuration"`,
  },
  gap: { xs: 1.5, md: 1.75 },
  alignItems: "stretch",
};

export const overviewGridItemSx = (area) => ({
  gridArea: area,
  minWidth: 0,
  "& > *": { height: "100%" },
});

export const overviewPanelSx = {
  minWidth: 0,
  height: "100%",
  display: "flex",
  flexDirection: "column",
  p: { xs: 1.45, md: 1.75, xl: 1.9 },
  borderRadius: 3,
  border: "1px solid rgba(85, 199, 216, 0.20)",
  bgcolor: "rgba(8, 18, 29, 0.92)",
  background:
    "linear-gradient(150deg, rgba(27, 111, 145, 0.16), rgba(8, 18, 29, 0.95) 46%)",
  boxShadow: "0 15px 36px rgba(0,0,0,0.18)",
};

export const overviewPanelHeaderSx = {
  display: "flex",
  alignItems: "center",
  gap: 0.9,
  mb: 1.3,
};

export const overviewPanelIconSx = {
  width: 31,
  height: 31,
  display: "grid",
  placeItems: "center",
  flexShrink: 0,
  borderRadius: 1.3,
  color: "secondary.light",
  bgcolor: "rgba(52, 170, 199, 0.12)",
  border: "1px solid rgba(89, 213, 218, 0.13)",
};

export const overviewPanelNumberSx = {
  minWidth: 25,
  height: 25,
  px: 0.55,
  display: "grid",
  placeItems: "center",
  borderRadius: 1.1,
  color: "secondary.light",
  bgcolor: "rgba(52, 185, 199, 0.12)",
  fontSize: 12.5,
  fontWeight: 950,
};

export const overviewPanelTitleSx = {
  fontSize: { xs: 17, xl: 18 },
  lineHeight: 1.2,
  fontWeight: 950,
};

export const overviewPanelCountSx = {
  ml: "auto",
  px: 0.8,
  py: 0.25,
  borderRadius: 99,
  color: "secondary.light",
  bgcolor: "rgba(50, 163, 194, 0.11)",
  border: "1px solid rgba(74, 200, 210, 0.16)",
  fontSize: 11.5,
  fontWeight: 850,
};

export const overviewInnerSurfaceSx = {
  minWidth: 0,
  borderRadius: 1.8,
  border: "1px solid rgba(255,255,255,0.08)",
  bgcolor: "rgba(4, 12, 21, 0.33)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.022)",
};

export const overviewIssueGridSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    sm: "minmax(0, 1.05fr) minmax(180px, 0.75fr)",
  },
  gap: 1.4,
  alignItems: "stretch",
};

export const overviewIssueRowsSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    sm: "repeat(2, minmax(0, 1fr))",
  },
  gap: 0.65,
};

export const overviewInformationRowSx = {
  display: "grid",
  gridTemplateColumns: "31px minmax(0, 1fr)",
  gap: 0.8,
  alignItems: "center",
  minWidth: 0,
  px: 0.85,
  py: 0.75,
  borderRadius: 1.35,
  border: "1px solid rgba(255,255,255,0.07)",
  bgcolor: "rgba(255,255,255,0.018)",
};

export const overviewInformationIconSx = (tone = "cyan") => ({
  width: 28,
  height: 28,
  display: "grid",
  placeItems: "center",
  borderRadius: "50%",
  color:
    tone === "green"
      ? "success.light"
      : tone === "red"
        ? "error.light"
        : "secondary.light",
  bgcolor:
    tone === "green"
      ? "rgba(66, 194, 139, 0.11)"
      : tone === "red"
        ? "rgba(231, 79, 79, 0.10)"
        : "rgba(48, 157, 197, 0.11)",
});

export const overviewHeroSx = {
  position: "relative",
  minHeight: { xs: 178, sm: "100%" },
  display: "grid",
  placeItems: "center",
  overflow: "hidden",
  borderRadius: 2,
  border: "1px solid rgba(66, 192, 208, 0.10)",
  bgcolor: "rgba(9, 29, 42, 0.28)",
  "&::before": {
    content: '""',
    position: "absolute",
    width: 220,
    height: 220,
    borderRadius: "50%",
    border: "1px solid rgba(61, 202, 215, 0.13)",
    boxShadow:
      "0 0 0 26px rgba(61,202,215,0.025), 0 0 0 52px rgba(61,202,215,0.018)",
    transform: "rotateX(68deg)",
  },
};

export const overviewAlternativeRowSx = {
  display: "grid",
  gridTemplateColumns: "36px minmax(0, 1fr) auto",
  gap: 0.9,
  alignItems: "center",
  minWidth: 0,
  px: 1,
  py: 0.9,
  borderRadius: 1.55,
  border: "1px solid rgba(255,255,255,0.078)",
  bgcolor: "rgba(255,255,255,0.022)",
  transition: "border-color 150ms ease, background-color 150ms ease",
  "&:hover": {
    borderColor: "rgba(84, 205, 214, 0.23)",
    bgcolor: "rgba(52, 153, 184, 0.045)",
  },
};

export const overviewScrollableListSx = {
  minHeight: 0,
  maxHeight: { xs: 380, xl: 430 },
  overflow: "auto",
  pr: 0.35,
};

export const overviewCriteriaViewportSx = {
  minHeight: 0,
  maxHeight: { xs: 430, xl: 500 },
  overflow: "auto",
  pr: 0.4,
  pb: 0.25,
};

export const overviewCriterionRowSx = (depth, hasChildren) => ({
  position: "relative",
  minWidth: "max-content",
  ml: depth * 2.15,
  mb: 0.65,
  "&::before":
    depth > 0
      ? {
          content: '""',
          position: "absolute",
          left: -15,
          top: -10,
          bottom: -10,
          width: 1,
          bgcolor: "rgba(76, 201, 211, 0.20)",
        }
      : undefined,
  "&::after":
    depth > 0
      ? {
          content: '""',
          position: "absolute",
          left: -15,
          top: 23,
          width: 12,
          height: 1,
          bgcolor: "rgba(76, 201, 211, 0.30)",
        }
      : undefined,
  ...(hasChildren
    ? {
        "& > .criterion-surface": {
          borderColor: "rgba(70, 194, 207, 0.16)",
        },
      }
    : {}),
});

export const overviewCriterionSurfaceSx = {
  minWidth: 260,
  display: "flex",
  alignItems: "center",
  gap: 0.7,
  px: 0.85,
  py: 0.72,
  borderRadius: 1.45,
  border: "1px solid rgba(255,255,255,0.075)",
  bgcolor: "rgba(255,255,255,0.020)",
};

export const overviewParticipationGridSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    sm: "minmax(0, 1.05fr) minmax(150px, 0.75fr)",
    md: "minmax(0, 1fr)",
    lg: "minmax(0, 1.05fr) minmax(150px, 0.75fr)",
  },
  gap: 1.1,
  alignItems: "stretch",
};

export const overviewParticipantRowSx = {
  display: "grid",
  gridTemplateColumns: "38px minmax(0, 1fr) auto",
  gap: 0.8,
  alignItems: "center",
  minWidth: 0,
  px: 0.9,
  py: 0.8,
  borderRadius: 1.5,
  border: "1px solid rgba(255,255,255,0.075)",
  bgcolor: "rgba(255,255,255,0.02)",
};

export const overviewParticipationChartSx = {
  minHeight: 218,
  display: "grid",
  placeItems: "center",
  p: 1,
  borderRadius: 1.8,
  border: "1px solid rgba(255,255,255,0.075)",
  bgcolor: "rgba(4, 12, 21, 0.30)",
};

export const overviewConfigRowSx = {
  display: "grid",
  gridTemplateColumns: "29px minmax(0, 0.9fr) minmax(0, 1.15fr)",
  gap: 0.7,
  alignItems: "center",
  minWidth: 0,
  py: 0.72,
  "&:not(:last-child)": {
    borderBottom: "1px solid rgba(255,255,255,0.07)",
  },
};

export const overviewDomainSx = {
  px: 0.9,
  py: 0.75,
  borderRadius: 1.4,
  border: "1px solid rgba(255,255,255,0.075)",
  bgcolor: "rgba(255,255,255,0.018)",
};

export const overviewFooterSx = {
  display: "grid",
  gridTemplateColumns: {
    xs: "minmax(0, 1fr)",
    sm: "repeat(2, minmax(0, 1fr))",
    lg: "auto auto auto minmax(260px, 1fr)",
  },
  gap: { xs: 0.75, lg: 0 },
  alignItems: "center",
  mt: { xs: 1.5, md: 1.75 },
  px: { xs: 1.1, md: 1.35 },
  py: 0.9,
  borderRadius: 2.2,
  border: "1px solid rgba(84, 199, 211, 0.15)",
  bgcolor: "rgba(8, 19, 30, 0.80)",
  "& > *": {
    minWidth: 0,
  },
  "& > *:not(:last-child)": {
    borderRight: { xs: 0, lg: "1px solid rgba(255,255,255,0.08)" },
    pr: { xs: 0, lg: 1.35 },
    mr: { xs: 0, lg: 1.35 },
  },
};
